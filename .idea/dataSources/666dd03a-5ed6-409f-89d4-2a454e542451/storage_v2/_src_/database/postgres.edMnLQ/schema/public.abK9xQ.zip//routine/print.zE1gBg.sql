create function print() returns text
    language plpgsql
as
$$
declare
    j        int;
    i        int;
    is_prime bool default false;
    con_str  varchar default '';
begin


    for i in 3..1000
        loop


            for j in 2..i / 2
                loop
                    --                     raise info 'i=%, j=%',i,j;
                    if i % j = 0 then
                        is_prime = false;
                        exit;
                    end if;
                end loop;

            if is_prime then
                con_str := concat(con_str,i,'&');
            end if;

            is_prime = true;

        end loop;


    return left(con_str,length(con_str)-1);

end;
$$;

alter function print() owner to postgres;

